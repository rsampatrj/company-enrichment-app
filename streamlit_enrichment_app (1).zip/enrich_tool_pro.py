import streamlit as st
import pandas as pd

st.title("Company Enrichment Tool")

uploaded_file = st.file_uploader("Upload a CSV with 'Company Name' column")

if uploaded_file:
    df = pd.read_csv(uploaded_file)
    st.write("Uploaded Data:", df.head())

    # Fake enrichment for demonstration
    df["Website"] = df["Company Name"].apply(lambda x: f"https://www.{x.replace(' ', '').lower()}.com")
    df["LinkedIn"] = df["Company Name"].apply(lambda x: f"https://www.linkedin.com/company/{x.replace(' ', '-').lower()}")

    st.write("Enriched Data:", df)
    st.download_button("Download Enriched CSV", df.to_csv(index=False), "enriched_companies.csv", "text/csv")
